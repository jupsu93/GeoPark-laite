<?php
	//echo "user_view näkymä";
?>

<!DOCTYPE html>
<html>
<head>
	<title>GeoPark-LogIn</title>
</head>
<body>
	<table>
		<tr>
			<th>LogIn/main page</th>
			
		</tr>
		<?php
	