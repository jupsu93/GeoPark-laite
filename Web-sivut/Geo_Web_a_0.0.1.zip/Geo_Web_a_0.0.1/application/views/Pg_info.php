<?php
	//echo "user_view näkymä";
?>

<!DOCTYPE html>
<html>
<head>
	<title>info page</title>
</head>
<body>
	<table>
		<tr>
			<th>This is info page</th>
			
		</tr>
		<?php
